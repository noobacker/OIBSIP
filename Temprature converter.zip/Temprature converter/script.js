function convertTemperature() {
    var temperatureInput = document.getElementById("temperature").value;
    var unit = document.getElementById("unit").value;
    var convertedTemperature;
    
    if (unit === "celsius") {
      convertedTemperature = (temperatureInput * 9/5) + 32;
      document.getElementById("result").innerHTML = "Converted Temperature: " + convertedTemperature + " °F";
    } else if (unit === "fahrenheit") {
      convertedTemperature = (temperatureInput - 32) * 5/9;
      document.getElementById("result").innerHTML = "Converted Temperature: " + convertedTemperature + " °C";
    } else if (unit === "kelvin") {
      convertedTemperature = parseFloat(temperatureInput) + 273.15;
      document.getElementById("result").innerHTML = "Converted Temperature: " + convertedTemperature + " K";
    }
  }
  