const taskInput = document.getElementById("taskInput");
const pendingList = document.getElementById("pendingList");
const completedList = document.getElementById("completedList");

function addTask() {
  const taskText = taskInput.value.trim();
  if (taskText !== "") {
    const taskItem = document.createElement("li");
    taskItem.textContent = taskText;

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.className = "delete";
    deleteButton.onclick = function () {
      taskItem.remove();
    };

    const editButton = document.createElement("button");
    editButton.textContent = "Edit";
    editButton.className = "edit";
    editButton.onclick = function () {
      const newText = prompt("Enter new text");
      if (newText !== null) {
        taskItem.textContent = newText.trim();
      }
    };

    const completeButton = document.createElement("button");
    completeButton.textContent = "Complete";
    completeButton.className = "complete";
    completeButton.onclick = function () {
      taskItem.remove();
      completedList.appendChild(taskItem);
      completeButton.remove();
    };

    taskItem.appendChild(deleteButton);
    taskItem.appendChild(editButton);
    taskItem.appendChild(completeButton);

    pendingList.appendChild(taskItem);
    taskInput.value = "";
  }
}
